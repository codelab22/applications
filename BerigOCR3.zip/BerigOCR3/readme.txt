OCR berig.exe
	start
		prompter for Excelfil der skal have OCR kolonne
		-marker den Excel fil der skal beriges med OCR.
	input
		filtyper
		xls/xlsx: programmet danner en csv fil fra disse
		csv: 	default, programmet kalder ikke Excel
	funktion
		finder kolonne "medlemsnr" og kolonne "projektnr" og danner et 15 cifret OCR på form "YYPPPPMMMMMMM0K"
			hvor 
				YY=Årstal
				PPPP=projeknr højrestillet
				MMMMMMMM=medlemsnr højrestillet
				0=0
				K=modulus kontrol ciffer
			(Format(Now, "yy") + Format(projnr, "0000") + Format(medlemsnr, "0000000") + "0")
	output
		resultat.csv
	brug
		ændr ikke i resultat.csv da Excel default runder af på mangecifrede tal, så gem ikke fra Excel.
		hvis filen skal tjekkes kan den åbnes i notepad i stedet.
